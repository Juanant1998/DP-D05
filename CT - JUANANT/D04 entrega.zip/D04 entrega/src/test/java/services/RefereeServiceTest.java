package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Complaint;
import domain.Note;
import domain.Referee;
import domain.Report;

import security.Authority;
import security.UserAccount;
import utilities.AbstractTest;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})

@Transactional
public class RefereeServiceTest  extends AbstractTest{
	@Autowired
	private RefereeService refereeService;
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private NoteService noteService;

	@Test
	public void registerTest(){
		super.authenticate("referee1");
		Referee h;
		h = this.refereeService.findOne(super.getEntityId("referee1"));
		UserAccount  n  = new UserAccount();
		Authority  s  = new Authority();
		n.setUsername("paquito");
		n.setPassword("21232f297a57a5a743894a0e4a801fc2");
		s.setAuthority(Authority.REFEREE);
		Collection<Authority> authorities = new ArrayList<>();
		authorities.add(s);
		n.setAuthorities(authorities);
		h.setUserAccount(n);
		
		Referee  registrado = this.refereeService.register(h);
		registrado.setUserAccount(n);
		Assert.isTrue(registrado.getIsBanned().equals(h.getIsBanned()));
		super.authenticate(null);
	}
	
	
	
	
	@Test 
	public void testSaveActors(){
		//Actor
		Collection<Referee> referees = new ArrayList<>();
		Referee guardando=refereeService.findOne(super.getEntityId("referee3"));
		refereeService.save(guardando);
		referees.add(guardando);
		Assert.isTrue(referees.contains(guardando));
		
	}
	@Test
	public void  testDeleteActor(){
		Referee borrando= refereeService.findOne(super.getEntityId("referee3"));
			refereeService.delete(borrando);
			Assert.isNull(refereeService.findOne(borrando.getId()));
	}
	@Test
	public void  findOneOk(){
		Referee  find = refereeService.findOne(super.getEntityId("referee3"));
		 int  findId= find.getId();
		 Assert.notNull(refereeService.findOne(findId));
	}
	@Test
	public void FindAll(){
		Collection<Referee> referees;
		referees = this.refereeService.findAll();
		Assert.isTrue(!referees.isEmpty());
		
	}
	@Test
	public void CreateTest(){
		Referee  create= refereeService.create();
		Assert.notNull(create);
		
	}
	
	@Test
	public void findFreeComplaintsTest(){
		super.authenticate("referee1");
		Collection<Complaint> comps = refereeService.findFreeComplaints();
		Assert.isTrue(comps.isEmpty());
		super.authenticate(null);
	}
	
	@Test
	public void findMyComplaintsTest(){
		super.authenticate("referee1");
		Collection<Complaint> comps = refereeService.findMyComplaints();
		Assert.isTrue(!comps.isEmpty());
		super.authenticate(null);
	}
	@Test
	public void editReportTest(){
		super.authenticate("referee1");
		Report r = new Report();
		Report r2 = refereeService.editReport(r);
		Assert.notNull(r2);
		super.authenticate(null);
	}
	
	@Test
	public void deleteReportTest(){
		super.authenticate("referee1");
		Report guardando=reportService.findOne(super.getEntityId("report1"));
		this.refereeService.deleteReport(guardando);
		Assert.isNull(this.reportService.findOne(guardando.getId()));
		super.authenticate(null);
	}
	
	
	@Test
	public void findMyReportsTest(){
		super.authenticate("referee1");
		Collection<Report> comps = refereeService.findMyReports();
		Assert.isTrue(!comps.isEmpty());
		super.authenticate(null);
	}
	
	@Test
	public void createNote(){
		super.authenticate("referee1");
		Report r =reportService.findOne(super.getEntityId("report1"));
		Note n = new Note();
		Note res = refereeService.createNote(n, r);
		Assert.notNull(res);
		super.authenticate(null);
	}
	
	@Test
	public void writeCommentTest(){
		super.authenticate("referee1");
		Note n =noteService.findOne(super.getEntityId("note1"));
		Note res = refereeService.writeComment("Me gusta", n);
		Assert.isTrue(res.getComment().contains("Me gusta"));
		super.authenticate(null);
	}
}
	