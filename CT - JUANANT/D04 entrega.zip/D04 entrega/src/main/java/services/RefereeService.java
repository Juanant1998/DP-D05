package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ComplaintRepository;
import repositories.RefereeRepository;
import repositories.ReportRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;


import domain.Complaint;
import domain.MessageBox;
import domain.Note;
import domain.Profile;
import domain.Referee;
import domain.Report;

@Service
@Transactional
public class RefereeService {   //comprobar en cada metodo que no est� baneado.
	
	@Autowired
	private RefereeRepository refereeRepository;
	

	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private NoteService noteService;
		
	@Autowired
	private ActorService actorService;
	
	@Autowired
	private ComplaintRepository complaintRepository;

	@Autowired
	private ReportRepository reportRepository;
	
	
	public Referee create(){
		final Referee result = new Referee();
		final UserAccount user = new UserAccount();
		result.setProfiles(new ArrayList<Profile>());
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		final Collection<Authority> r = new ArrayList<Authority>();
		r.add(a);
		user.setAuthorities(r);
		result.setUserAccount(user);

		return result;	
	}
	
	public void checkAuthority() {
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount ua;
		ua = LoginService.getPrincipal();
		Assert.notNull(ua);
		final Collection<Authority> auth = ua.getAuthorities();
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(auth.contains(a));
	}
		
	
	
	public Referee register(final Referee hw) {

		Assert.notNull(hw.getUserAccount());
		Assert.notNull(hw);
		//Assert.notEmpty(hw.getProfiles());
		

		final Referee result = this.create();
		result.setAddress(hw.getAddress());
		result.setEmail(hw.getEmail());
		result.setMiddleName(hw.getMiddleName());
		result.setName(hw.getName());
		result.setPhone(hw.getPhone());
		result.setPhoto(hw.getPhoto());
		result.setProfiles(hw.getProfiles());
		result.getUserAccount().setPassword(hw.getUserAccount().getPassword());
		result.getUserAccount().setUsername(hw.getUserAccount().getUsername());
		result.setIsBanned(hw.getIsBanned());
		result.setIsSuspicious(hw.getIsSuspicious());

		final MessageBox in = this.actorService.createNewMessageBox(hw.getUserAccount().getUsername(), "-in");
		final MessageBox out = this.actorService.createNewMessageBox(hw.getUserAccount().getUsername(), "-out");
		final MessageBox trash = this.actorService.createNewMessageBox(hw.getUserAccount().getUsername(), "-trash");
		final MessageBox spam = this.actorService.createNewMessageBox(hw.getUserAccount().getUsername(), "-spam");

		final Collection<MessageBox> msboxes = new ArrayList<MessageBox>();
		msboxes.add(in);
		msboxes.add(out);
		msboxes.add(trash);
		msboxes.add(spam);

		result.setMessageBoxes(msboxes);
		final Referee x = this.save(result);

		return x;

	}
	public Collection<Referee> findAll(){
		return refereeRepository.findAll();
	}
	
	public Referee findOne(int refereeId){
		return refereeRepository.findOne(refereeId);
	}
	
	public Referee save(Referee referee){
		return refereeRepository.save(referee);
	}
	
	public void delete(Referee referee){
		refereeRepository.delete(referee);
	}
	
	public Collection<Complaint> findFreeComplaints(){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		
		
		Collection<Complaint> res = complaintRepository.getComplaintsFree();
		
		return res;
	}
	
	public Collection<Complaint> findMyComplaints(){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		
		Collection<Complaint> res = complaintRepository.getMyComplaints(userAccount);
		
		return res;
	}
	
	public Report editReport(Report r){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		Assert.isTrue(!r.isDraftMode());
		
		Report res = reportService.save(r);
		
		return res;
	}
	
	public void deleteReport(Report r){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		Assert.isTrue(!r.isDraftMode());
		
		
		reportService.delete(r);
	}
	
	public Collection<Report> findMyReports(){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		
		Collection<Report> res = reportRepository.getMyRepositories(userAccount);
		
		return res;
	}
	
	public Note createNote(Note n, Report r){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		
	    Assert.isTrue(!r.isDraftMode()); 
		r.getNotes().add(n);
	    
		noteService.save(n);
		
		return n;
	}
	
	public Note writeComment(String s, Note n){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		
		Assert.isTrue(this.findMyNotes().contains(n));
		
		
		
		n.setComment(n.getComment() + "\n Comentario del usuario " + LoginService.getPrincipal().getUsername() + ": " + s);
		Note res = noteService.save(n);
		
		return res;
	}
	
	private Collection<Note> findMyNotes(){
		Assert.isTrue(!actorService.isActualActorBanned());
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		
		final Authority a = new Authority();
		a.setAuthority(Authority.REFEREE);
		Assert.isTrue(userAccount.getAuthorities().contains(a));
		
		Collection<Note> res = noteService.findAll();
		
		for(Report r : this.findMyReports()){
		  res.addAll(r.getNotes());
		}
		
		return res;
	}

}
