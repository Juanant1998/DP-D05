package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import security.UserAccount;

import domain.Complaint;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint,Integer> {


	@Query("select c from Complaint c where c.report = null")
	Collection<Complaint> getComplaintsFree();
	
	@Query("select c from Complaint c where c.report.referee.userAccount = ?1")
	Collection<Complaint> getMyComplaints(UserAccount ua);

}
